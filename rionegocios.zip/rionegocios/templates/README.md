Use this directory to override template, theme and \[pre\]process functions.

Please refer to the @link registry Theme Registry @endlink topic for more info.
